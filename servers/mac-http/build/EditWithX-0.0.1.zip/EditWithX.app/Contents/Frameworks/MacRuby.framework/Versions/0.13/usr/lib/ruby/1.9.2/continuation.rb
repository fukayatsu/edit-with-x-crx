raise LoadError, "continuations are not supported in MacRuby yet"
